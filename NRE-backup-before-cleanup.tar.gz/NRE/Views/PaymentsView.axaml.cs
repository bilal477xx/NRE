using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using Avalonia.Controls;    
using Avalonia.Interactivity;
using MsBox.Avalonia;
using NRE.Models;
using NRE.Models.Abstracts;
using NRE.Models.Entities;
using NRE.Models.Entities.People;
using NRE.Models.Wrapper;

namespace NRE.Views;

public partial class PaymentsView : UserControl
{
    private DataStore _store = null!;

    public DataStore Store
    {
        get => _store;
        set
        {
            
            _store = value;
            LbTransactions.ItemsSource = _store.Transactions;
            CmbEstates.ItemsSource = _store.Estates;
            _store.People.CollectionChanged += (_, _) => RefreshPeople();
            _store.Estates.CollectionChanged += (_, _) => ResetForm();
            
            RefreshPeople();
        }
    }

    private Transaction? _currentTransaction;
    private List<TypeDisplayWrapper> _paymentMethods = new();
    
    public PaymentsView()
    {
        InitializeComponent();
        LoadPaymentMethods();
        ResetForm();
    }
    
    private void RefreshPeople()
    {
        var selectedSeller = CmbSeller.SelectedItem;
        var selectedBuyer = CmbBuyer.SelectedItem;

        CmbSeller.ItemsSource = _store.People.OfType<Seller>().ToList();
        CmbBuyer.ItemsSource = _store.People.OfType<Buyer>().ToList();

        CmbSeller.SelectedItem = selectedSeller;
        CmbBuyer.SelectedItem = selectedBuyer;
        
        SpGeneralForm.DataContext = _currentTransaction;
    }
    
    private void LoadPaymentMethods()
    {
        Assembly? assembly = Assembly.GetAssembly(typeof(Payment));

        if (assembly == null)
        {
            MessageBoxManager.GetMessageBoxStandard("Error", "No assembly found").ShowAsync();
            return;
        }
        
        _paymentMethods = assembly.GetTypes()
            .Where(t => t.IsClass && !t.IsAbstract && t.IsSubclassOf(typeof(Payment)))
            .Select(t => new TypeDisplayWrapper
            {
                ClassType   = t,
                DisplayName = GetClassDescription(t),
            })
            .ToList();
        
        CmbPaymentMethods.ItemsSource = _paymentMethods;
    }

    private string GetClassDescription(Type type)
    {
        var attr = type.GetCustomAttribute<DescriptionAttribute>();
        return attr?.Description ?? type.Name;
    }

    private async void BtnAdd_OnClick(object? sender, RoutedEventArgs e)
    {
        if (_currentTransaction is not { Estate: { } estate, Buyer: { } buyer, Payment: { } payment })
        {
            await MessageBoxManager.GetMessageBoxStandard("Incomplete",
                "Select an estate, a buyer and a payment method.").ShowAsync();
            return;
        }

        buyer.Payment = payment;
        estate.Buyer = buyer;
        Store.Transactions.Add(_currentTransaction);
        ResetForm();
    }

    private void ResetForm()
    {
        _currentTransaction = new Transaction();

        if (CmbPaymentMethods.SelectedItem is TypeDisplayWrapper wrapper)
            _currentTransaction.Payment = (Payment?) Activator.CreateInstance(wrapper.ClassType);

        SpGeneralForm.DataContext = _currentTransaction;
        ShowPayment(_currentTransaction.Payment);
        CmbSeller.IsEnabled = true;
        CmbBuyer.IsEnabled = true;
    }

    private void BtnRemove_OnClick(object? sender, RoutedEventArgs e)
    {
        if (LbTransactions.SelectedItem is Transaction selectedTransaction)
        {
            Store.Transactions.Remove(selectedTransaction);
            ResetForm();
        }
        else
        {
            MessageBoxManager.GetMessageBoxStandard("Error", "No transaction found").ShowAsync();
        }
    }
    
    private void BtnEdit_OnClick(object? sender, RoutedEventArgs e)
    {
        if (LbTransactions.SelectedItem is Transaction selectedTransaction)
        {
            if (_currentTransaction == null)
            {
                MessageBoxManager.GetMessageBoxStandard("Error", "No transaction found").ShowAsync();
                return;
            }
            
            Store.Transactions[Store.Transactions.IndexOf(selectedTransaction)] = _currentTransaction;
            ResetForm();
        }
        else
        {
            MessageBoxManager.GetMessageBoxStandard("Error", "No transaction found").ShowAsync();
        }
    }

    private void LbTransactions_OnSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (LbTransactions.SelectedItem is Transaction selectedTransaction)
        {
            _currentTransaction = selectedTransaction;
            CmbPaymentMethods.SelectedItem = _paymentMethods
                .FirstOrDefault(w => w.ClassType == selectedTransaction.Payment?.GetType());
            SpGeneralForm.DataContext = _currentTransaction;
            ShowPayment(_currentTransaction.Payment);
            
            SpEditButtons.IsVisible = true;
            BtnAdd.IsVisible = false;
        }
        else
        {
            SpEditButtons.IsVisible = false;
            BtnAdd.IsVisible = true;
            ResetForm();
        }
    }

    private void CmbPaymentMethods_OnSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (_currentTransaction == null ||
            CmbPaymentMethods.SelectedItem is not TypeDisplayWrapper wrapper) return;

        if (_currentTransaction.Payment?.GetType() == wrapper.ClassType) return;

        if (Activator.CreateInstance(wrapper.ClassType) is Payment newPayment)
        {
            if (_currentTransaction.Payment != null)
            {
                newPayment.Amount = _currentTransaction.Payment.Amount;
                newPayment.Date = _currentTransaction.Payment.Date;
            }
            _currentTransaction.Payment = newPayment;
            ShowPayment(newPayment);
        }
    }

    private void CmbEstates_OnSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (CmbEstates.SelectedItem is Estate selectedEstate)
        {
            if (selectedEstate.Seller != null)
            {
                CmbSeller.SelectedItem = selectedEstate.Seller;
                CmbSeller.IsEnabled = false;
            }
            else
            {
                CmbSeller.IsEnabled = true;
            }

            if (selectedEstate.Buyer != null)
            {
                CmbBuyer.SelectedItem = selectedEstate.Buyer;
                CmbBuyer.IsEnabled = false;
            }
            else
            {
                CmbBuyer.IsEnabled = true;
            }
        }
    }
    
    private void ShowPayment(Payment? payment)
    {
        SpPaymentCommon.DataContext = payment;
        SpPaymentCommon.IsEnabled = payment != null;
        DynamicForm.Content = payment;
    }
}