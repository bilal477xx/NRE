using System;

namespace NRE.Models.Abstracts;

public abstract class Person
{
    public string Name { get; set; }
    public Address Address { get; set; }

    protected Person(string name, Address address)
    {
        Name = name;
        Address = address;
    }

    public abstract string GetDescription();
    
    /// <summary>
    /// Common details between all 'person' details
    /// </summary>
    /// <returns>returns common details between all 'person' details</returns>
    protected virtual string GetCommonDetails() =>
        string.Join(Environment.NewLine,
            $"Name: {Name}",
            $"Address: {Address}");

    public override string ToString() => GetDescription();
}