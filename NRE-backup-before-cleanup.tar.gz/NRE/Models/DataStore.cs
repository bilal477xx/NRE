using System.Collections.ObjectModel;
using NRE.Models.Abstracts;
using NRE.Models.Entities;

namespace NRE.Models;

public class DataStore
{
    public ObservableCollection<Estate> Estates { get; } = new();
    public ObservableCollection<Person> People { get; } = new();
    public ObservableCollection<Transaction> Transactions { get; } = new();
}