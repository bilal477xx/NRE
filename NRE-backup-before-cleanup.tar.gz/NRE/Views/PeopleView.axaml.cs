using System;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using MsBox.Avalonia;
using NRE.Models;
using NRE.Models.Abstracts;
using NRE.Models.Wrapper;

namespace NRE.Views;

public partial class PeopleView : UserControl
{
    private DataStore _store = null!;

    public DataStore Store
    {
        get => _store;
        set
        {
            _store = value;
            LbPeople.ItemsSource = _store.People;
        }
    }


    private Person? _currentPerson;
    
    public PeopleView()
    {
        InitializeComponent();
        LoadCmbPersonTypeItems();
        CmbCountry.ItemsSource = Enum.GetValues(typeof(Countries)).Cast<Countries>();
    }
    
    
    private void LoadCmbPersonTypeItems()
    {
        Assembly? assembly = Assembly.GetAssembly(typeof(Person));

        if (assembly == null)
        {
            MessageBoxManager.GetMessageBoxStandard("Error", "No assembly found").ShowAsync();
            return;
        }
        
        var wrapperPersonTypes = assembly.GetTypes()
            .Where(t => t.IsClass && !t.IsAbstract && t.IsSubclassOf(typeof(Person)))
            .Select(t => new TypeDisplayWrapper
            {
                ClassType   = t,
                DisplayName = GetClassDescription(t),
            })
            .ToList();
        
        CmbPersonType.ItemsSource = wrapperPersonTypes;
    }

    private string GetClassDescription(Type type)
    {
        var attr = type.GetCustomAttribute<DescriptionAttribute>();
        return attr?.Description ?? type.Name;
    }

    private void BtnAdd_OnClick(object? sender, RoutedEventArgs e)
    {
        if (_currentPerson != null)
        {
            Store.People.Add(_currentPerson);
            ResetForm();
        }
    }

    private void BtnRemove_OnClick(object? sender, RoutedEventArgs e)
    {
        if (LbPeople.SelectedItem is Person selectedPerson)
        {
            Store.People.Remove(selectedPerson);
            ResetForm();
        }
        else
        {
            MessageBoxManager.GetMessageBoxStandard("Error", "No Person found").ShowAsync();
        }
    }

    private void BtnEdit_OnClick(object? sender, RoutedEventArgs e)
    {
        
        if (LbPeople.SelectedItem is Person selectedPerson)
        {
            if (_currentPerson == null)
            {
                MessageBoxManager.GetMessageBoxStandard("Error", "No Person found").ShowAsync();
                return;
            }
            
            Store.People[Store.People.IndexOf(selectedPerson)] = _currentPerson;
            ResetForm();
        }
        else
        {
            MessageBoxManager.GetMessageBoxStandard("Error", "No Person found").ShowAsync();
        }
    }

    private void LbPeople_OnSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (LbPeople.SelectedItem is Person selectedPerson)
        {
            _currentPerson = selectedPerson;
            SpGeneralForm.DataContext = _currentPerson;
            DynamicForm.Content = _currentPerson;
            
            CmbPersonType.IsEnabled = false;
            SpEditButtons.IsVisible = true;
            BtnAdd.IsVisible = false;
        }
        else
        {
            CmbPersonType.IsEnabled = true;
            SpEditButtons.IsVisible = false;
            BtnAdd.IsVisible = true;
            ResetForm();
        }
    }

    private void CmbPersonType_OnSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        ResetForm();
    }
    
    
    private void ResetForm()
    {
        if (CmbPersonType.SelectedItem is not TypeDisplayWrapper selectedWrapper) return;
        
        _currentPerson = (Person?) Activator.CreateInstance(selectedWrapper.ClassType);
        if (_currentPerson == null)
        {
            MessageBoxManager.GetMessageBoxStandard("Error", "No Person found").ShowAsync();
            return;
        }

        _currentPerson.Address = new Address();
        SpGeneralForm.DataContext = _currentPerson;
        DynamicForm.Content = _currentPerson;
    }
    
    protected override void OnAttachedToVisualTree(VisualTreeAttachmentEventArgs e)
    {
        base.OnAttachedToVisualTree(e);
        if (_store == null) return;

        var selected = LbPeople.SelectedItem;
        LbPeople.ItemsSource = null;
        LbPeople.ItemsSource = _store.People;
        LbPeople.SelectedItem = selected;
    }
}