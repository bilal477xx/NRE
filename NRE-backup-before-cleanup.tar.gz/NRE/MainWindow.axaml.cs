using Avalonia.Controls;
using NRE.Models;

namespace NRE;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        var store = new DataStore();
        EstatesTab.Store = store;
        PeopleTab.Store = store;
        PaymentsTab.Store = store;
    }
}