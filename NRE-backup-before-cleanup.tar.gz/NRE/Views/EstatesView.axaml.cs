using System;
using System.Collections.Specialized;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Media.Imaging;
using Avalonia.Platform.Storage;
using MsBox.Avalonia;
using NRE.Models;
using NRE.Models.Abstracts;
using NRE.Models.Entities.People;
using NRE.Models.Enums;
using NRE.Models.Wrapper;

namespace NRE.Views;

public partial class EstatesView : UserControl
{
    private DataStore _store = null!;
    
    public DataStore Store
    {
        get => _store;
        set
        {
            if (_store != null) _store.People.CollectionChanged -= People_OnCollectionChanged;

            _store = value;
            LbEstates.ItemsSource = _store.Estates;
            _store.People.CollectionChanged += People_OnCollectionChanged;
            RefreshPersonLists();
        }
    }
    
    private Estate? _currentEstate;
    
    public EstatesView()
    {
        InitializeComponent();
        LoadCmbEstateTypeItems();
        CmbCountry.ItemsSource = Enum.GetValues(typeof(Countries)).Cast<Countries>();
        CmbLegalForm.ItemsSource = Enum.GetValues((typeof(LegalForm))).OfType<LegalForm>();
    }
    
    private void People_OnCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
    {
        RefreshPersonLists();
    }

    private void RefreshPersonLists()
    {
        var selectedSeller = CmbSeller.SelectedItem;
        var selectedBuyer = CmbBuyer.SelectedItem;

        CmbSeller.ItemsSource = _store.People.OfType<Seller>().ToList();
        CmbBuyer.ItemsSource = _store.People.OfType<Buyer>().ToList();
        
        CmbSeller.SelectedItem = selectedSeller;
        CmbBuyer.SelectedItem = selectedBuyer;
    }

    private void LoadCmbEstateTypeItems()
    {
        Assembly? assembly = Assembly.GetAssembly(typeof(Estate));

        if (assembly == null)
        {
            MessageBoxManager.GetMessageBoxStandard("Error", "No assembly found").ShowAsync();
            return;
        }
        
        var wrapperEstateTypes = assembly.GetTypes()
            .Where(t => t.IsClass && !t.IsAbstract && t.IsSubclassOf(typeof(Estate)))
            .Select(t => new TypeDisplayWrapper
            {
                ClassType   = t,
                DisplayName = GetClassDescription(t),
            })
            .ToList();
        
        CmbEstateType.ItemsSource = wrapperEstateTypes;
    }

    private string GetClassDescription(Type type)
    {
        var attr = type.GetCustomAttribute<DescriptionAttribute>();
        return attr?.Description ?? type.Name;
    }


    private void CmbEstateType_OnSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        ResetForm();
    }

    private void ResetForm()
    {
        if (CmbEstateType.SelectedItem is not TypeDisplayWrapper selectedWrapper) return;
        
        _currentEstate = (Estate?) Activator.CreateInstance(selectedWrapper.ClassType);
        if (_currentEstate == null)
        {
            MessageBoxManager.GetMessageBoxStandard("Error", "No Estate found").ShowAsync();
            return;
        }

        _currentEstate.Address = new Address();
        SpGeneralForm.DataContext = _currentEstate;
        DynamicEstateCategory.Content = _currentEstate;
        DynamicForm.Content = _currentEstate;
        ShowImage(null);
    }

    private void BtnAdd_OnClick(object? sender, RoutedEventArgs e)
    {
        if (_currentEstate != null)
        {
            Store.Estates.Add(_currentEstate);
            ResetForm();
        }
    }

    private void LbEstates_OnSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (LbEstates.SelectedItem is Estate selectedEstate)
        {
            _currentEstate = selectedEstate;
            SpGeneralForm.DataContext = _currentEstate;
            DynamicEstateCategory.Content = _currentEstate;
            DynamicForm.Content = _currentEstate;
            ShowImage(_currentEstate.ImagePath);
            
            CmbEstateType.IsEnabled = false;
            SpEditButtons.IsVisible = true;
            BtnAdd.IsVisible = false;
        }
        else
        {
            CmbEstateType.IsEnabled = true;
            SpEditButtons.IsVisible = false;
            BtnAdd.IsVisible = true;
            ResetForm();
        }
    }

    private void BtnEdit_OnClick(object? sender, RoutedEventArgs e)
    {
        if (LbEstates.SelectedItem is Estate selectedEstate)
        {
            if (_currentEstate == null)
            {
                MessageBoxManager.GetMessageBoxStandard("Error", "No Estate found").ShowAsync();
                return;
            }
            
            Store.Estates[Store.Estates.IndexOf(selectedEstate)] = _currentEstate;
            LbEstates.SelectedItem = null;
            ResetForm();
        }
        else
        {
            MessageBoxManager.GetMessageBoxStandard("Error", "No Estate found").ShowAsync();
        }
    }

    private void BtnRemove_OnClick(object? sender, RoutedEventArgs e)
    {
        if (LbEstates.SelectedItem is Estate selectedEstate)
        {
            Store.Estates.Remove(selectedEstate);
            ResetForm();
        }
        else
        {
            MessageBoxManager.GetMessageBoxStandard("Error", "No Estate found").ShowAsync();
        }
    }

    private async void BtnChooseImage_OnClick(object? sender, RoutedEventArgs e)
    {
        if (_currentEstate == null) return;

        var files = await TopLevel.GetTopLevel(this)!.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
        {
            Title = "Choose an image",
            AllowMultiple = false,
            FileTypeFilter = [FilePickerFileTypes.ImageAll]
        });

        var path = files.FirstOrDefault()?.TryGetLocalPath();
        if (path == null) return;

        _currentEstate.ImagePath = CopyToAppFolder(path);
        ShowImage(_currentEstate.ImagePath);
    }

    private void ShowImage(string? path)
    {
        (ImgEstate.Source as IDisposable)?.Dispose(); // free the previous image
        ImgEstate.Source = path != null && File.Exists(path)
            ? new Bitmap(path)
            : null;
    }

    private static string CopyToAppFolder(string sourcePath)
    {
        var folder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "NRE", "images");
        Directory.CreateDirectory(folder);

        var destination = Path.Combine(folder, $"{Guid.NewGuid()}{Path.GetExtension(sourcePath)}");
        File.Copy(sourcePath, destination);
        return destination;
    }
}