namespace NRE.Models;

public class Address
{
    private string _street;
    private int _zipCode;
    private string _city;
    private Countries _country;
    
    public string Street { get => _street; set => _street = value; }
    public int ZipCode { get => _zipCode; set => _zipCode = value; }
    public string City { get => _city; set => _city = value; }
    public Countries Country { get => _country; set => _country = value; }

    public Address()
    {
        _street = string.Empty;
        _zipCode = 0;
        _city = string.Empty;
    }

    public Address(string street, int zipCode, string city, Countries country)
    {
        _street = street;
        _zipCode = zipCode;
        _city = city;
        _country = country;
    }

    public override string ToString() => $"{Street}, {ZipCode} {City}, {Country}";
}