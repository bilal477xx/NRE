using System;
using System.ComponentModel;
using NRE.Models.Abstracts;

namespace NRE.Models.Entities.People;

[Description("Seller")]
public class Seller : Person
{
    private int _rating;

    public int Rating { 
        get => _rating;
        set
        {
            if (value < 0 || value > 10) throw new ArgumentOutOfRangeException(nameof(value), "Rating must be between 0 and 10");
            _rating = value;
        }
    }
    
    public Seller() : this(string.Empty, new Address(), 0) { }

    public Seller(string name, Address address, int rating) : base(name, address)
    {
        Rating = rating;
    }
    
    public override string GetDescription() =>
        string.Join(Environment.NewLine,
            "--- Seller ---",
            GetCommonDetails(),
            $"Rating: {Rating}");
}