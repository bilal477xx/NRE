using System;
using NRE.Models.Entities.People;
using NRE.Models.Enums;
using NRE.Models.Interfaces;

namespace NRE.Models.Abstracts;

public abstract class Estate : IEstate
{
    private int _area;

    public int Id { get; set; }
    public Address Address { get; set; }
    public LegalForm LegalForm { get; set; }
    public string ImagePath { get; set; }
    public Seller? Seller { get; set; }
    public Buyer? Buyer { get; set; }

    public int Area
    {
        get => _area;
        set
        {
            if (value < 0)
                _area = 0;
            _area = value;
        }
    }
    
    /// <summary>
    /// Short description with basic info about the estate
    /// </summary>
    public string ShortDescription =>
        $"#{Id} {GetType().Name} – {Address?.Street}, {Address?.City}";

    protected Estate() : this(0, new Address(), LegalForm.Ownership, 0, string.Empty) { }

    protected Estate(int id, Address address, LegalForm legalForm, int area, string imagePath)
    {
        Id = id;
        Address = address;
        LegalForm = legalForm;
        Area = area;
        ImagePath = imagePath;
    }

    public abstract string GetDescription();
    public abstract string GetCategory();
    
    /// <summary>
    /// Common details that are shared between all estate categories
    /// </summary>
    /// <returns>returns the common details of the estate</returns>
    protected virtual string GetCommonDetails() =>
        string.Join(Environment.NewLine,
            $"ID: {Id}",
            $"Category: {GetCategory()}",
            $"Address: {Address}",
            $"Legal form: {LegalForm}",
            $"Area: {Area} m²");
    
    public override string ToString() => GetDescription();

}