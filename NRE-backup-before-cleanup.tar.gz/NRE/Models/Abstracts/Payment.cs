using System;

namespace NRE.Models.Abstracts;

public abstract class Payment
{
    public int Amount { get; set; }
    public DateTime Date { get; set; }

    protected Payment() { }
    
    protected Payment(int amount, DateTime date)
    {
        Amount = amount;
        Date = date;
    }
    
    /// <summary>
    /// Common details between all payments details
    /// </summary>
    /// <returns>returns common details between all payments details</returns>
    protected virtual string GetCommonDetails() =>
        string.Join(Environment.NewLine,
            $"Amount: {Amount}Kr, {Date}");
    
    /// <summary>
    /// A description of the payment details
    /// </summary>
    /// <returns>returns the payments details</returns>
    public abstract string GetDescription();
    
    public override string ToString() => GetDescription();
}